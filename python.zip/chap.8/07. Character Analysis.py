# Chapter.8
# 07. Character Analysis
#
# I couldn't find a text.txt file.
