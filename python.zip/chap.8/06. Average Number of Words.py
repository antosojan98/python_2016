# Chapter.8
# 06. Average Number of Words
#
# I couldn't find a text.txt file.
