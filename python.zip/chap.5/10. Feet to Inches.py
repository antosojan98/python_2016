# Chapter.5
# 10. Feet to Inches

feet = float(input('Enter a number of feet: '))

def conver(feet):
    inches = feet * 12
    print(feet, 'feet is ', inches, 'inches')

conver(feet)
