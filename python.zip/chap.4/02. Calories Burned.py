# Chapter.4
# 02. Calories Burned

minutes = 10

while minutes <= 30:
    print(minutes * 4.2, 'calories')
    minutes += 5
