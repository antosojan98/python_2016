# Chapter.4
# 10. Tuition Increase

tuition = 8000
print('semester\t', 'tuition')
print('-' * 25)
for i in range(1, 11):
    tuition *= 1.03

    for h in range(1):
        print(format(i, '2.0f'), '\t\t$', end='')
        print(format(tuition , '7.2f'))

