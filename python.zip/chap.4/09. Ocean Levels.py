# Chapter.4
# 09. Ocean Levels

print('Year\t', 'milimeter')
for i in range(1, 26):
    print(format(i, '2.0f'), '\t', format(i * 1.6, '5.2f'), 'milimeter')
    
