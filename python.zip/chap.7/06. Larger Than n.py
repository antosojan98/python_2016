# Chapter.7
# 06. Larger Than n


def compare(numbers_list, number):
    for i in numbers_list:
        if i > number:
            print(i)

compare(numbers_list, number)





    
